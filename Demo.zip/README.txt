PagerDuty Demo - starting with eCommerce (to be extended to other verticals)

Shopping cart based on:

https://codepen.io/justinklemm/pen/zAdoJ.

All functionality and calculations are implemented via Javascript. There are responsive breakpoints at 650px and 350px (though you can't view the latter in Chrome because it won't scale down below 400px). Breakpoints are based on logical UI decisions, not particular device specifications.